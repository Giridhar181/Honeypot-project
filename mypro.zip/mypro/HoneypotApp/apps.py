from django.apps import AppConfig


class HoneypotappConfig(AppConfig):
    name = 'HoneypotApp'
